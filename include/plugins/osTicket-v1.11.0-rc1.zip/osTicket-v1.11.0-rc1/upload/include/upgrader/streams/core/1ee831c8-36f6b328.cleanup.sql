-- drop useless updated column
ALTER TABLE  `%TABLE_PREFIX%team_member` DROP  `updated`;
